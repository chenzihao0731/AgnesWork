import React from "react";
import type { ToolInvocation } from "../lib/agent/agent";
import { FileTree } from "./FileTree";
import { MarkdownRenderer } from "./MarkdownRenderer";

/** 单个工具调用卡片 */
function ToolCallCard({ inv }: { inv: ToolInvocation }) {
  const isRunning = inv.status === "running";
  const isSuccess = inv.status === "success";
  const isError = inv.status === "error";

  return (
    <div className="glass rounded-xl p-3 space-y-2 mt-2">
      {/* 标题栏 */}
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0 flex-1">
          <div className="flex items-center gap-2">
            {/* 工具图标 */}
            <span
              className={`inline-flex items-center justify-center w-6 h-6 rounded-md text-xs font-bold shrink-0 ${
                inv.name === "list_directory"
                  ? "bg-amber-600/30 text-amber-300"
                  : inv.name === "read_text_file" || inv.name === "write_text_file"
                  ? "bg-sky-600/30 text-sky-300"
                  : inv.name === "read_image_file"
                  ? "bg-violet-600/30 text-violet-300"
                  : inv.name === "generate_image" || inv.name === "image_to_image"
                  ? "bg-pink-600/30 text-pink-300"
                  : inv.name === "generate_video"
                  ? "bg-blue-600/30 text-blue-300"
                  : "bg-ink-700/80 text-ink-200"
              }`}
            >
              {toolIcon(inv.name)}
            </span>
            <code className="text-xs text-ink-200 font-mono truncate">
              {inv.name}
            </code>
          </div>
          {inv.infoText && (
            <div className="mt-1 text-[11px] text-ink-400 leading-relaxed">
              {inv.infoText}
            </div>
          )}
        </div>

        {/* 状态徽章 */}
        {isRunning && (
          <span className="inline-flex items-center gap-1.5 text-[11px] text-amber-300 shrink-0">
            <span className="w-1.5 h-1.5 rounded-full bg-amber-300 tool-blink" />
            {inv.progress}%
          </span>
        )}
        {isSuccess && (
          <span className="inline-flex items-center gap-1 text-[11px] text-emerald-300 shrink-0">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
            完成
          </span>
        )}
        {isError && (
          <span className="inline-flex items-center gap-1 text-[11px] text-rose-300 shrink-0">
            <span className="w-1.5 h-1.5 rounded-full bg-rose-400" />
            失败
          </span>
        )}
      </div>

      {/* 参数预览（prompt） */}
      {inv.args?.prompt && (
        <div className="text-[11.5px] text-ink-400 bg-ink-900/60 rounded-md p-2 border border-ink-800/60">
          <span className="text-ink-500 font-mono">prompt: </span>
          <span className="text-ink-200 break-words leading-relaxed">
            {String(inv.args.prompt).slice(0, 200)}
            {String(inv.args.prompt).length > 200 ? "…" : ""}
          </span>
        </div>
      )}

      {/* 其他关键参数 */}
      {Object.entries(inv.args || {})
        .filter(([k]) => k !== "prompt" && k !== "path")
        .slice(0, 3)
        .map(([k, v]) => (
          <div
            key={k}
            className="text-[11.5px] text-ink-400 bg-ink-900/40 rounded px-2 py-1"
          >
            <span className="text-ink-500 font-mono">{k}: </span>
            <span className="text-ink-200">{String(v).slice(0, 80)}</span>
          </div>
        ))}

      {/* 动画进度条 */}
      {isRunning && (
        <div className="relative h-1.5 rounded-full bg-ink-800 overflow-hidden">
          <div
            className="absolute left-0 top-0 h-full rounded-full bg-gradient-to-r from-amber-400 via-amber-300 to-amber-500 transition-all duration-700"
            style={{ width: `${Math.min(100, inv.progress)}%` }}
          />
          {/* 动态条纹动画 */}
          <div
            className="absolute inset-0 overflow-hidden rounded-full"
            style={{
              backgroundImage:
                "repeating-linear-gradient(90deg, transparent 0px, transparent 8px, rgba(255,255,255,0.08) 8px, rgba(255,255,255,0.08) 16px)",
              animation: "progress-shimmer 1.5s linear infinite",
            }}
          />
        </div>
      )}

      {/* 文件树（list_directory） */}
      {inv.name === "list_directory" && inv.resultJson && (
        <FileTree resultJson={inv.resultJson} />
      )}

      {/* 产物展示（图 / 视频） */}
      {inv.artifacts.length > 0 && (
        <div className="grid grid-cols-1 gap-2 pt-1">
          {inv.artifacts.map((a, i) => (
            <div
              key={i}
              className="relative rounded-xl overflow-hidden border border-ink-700/60 bg-ink-900/60"
            >
              {a.kind === "image" ? (
                <img
                  src={a.url}
                  alt="generated"
                  className="w-full h-auto max-h-[400px] object-contain"
                  loading="lazy"
                />
              ) : (
                <video
                  src={a.url}
                  controls
                  playsInline
                  className="w-full max-h-[400px] object-contain bg-black"
                  preload="metadata"
                />
              )}
              <a
                href={a.url}
                target="_blank"
                rel="noreferrer noopener"
                className="block text-[11px] text-ink-400 hover:text-white truncate px-2.5 py-2 border-t border-ink-800/60 bg-ink-950/40"
              >
                {a.url.length > 100 ? a.url.slice(0, 100) + "…" : a.url}
              </a>
            </div>
          ))}
        </div>
      )}

      {/* 错误 */}
      {isError && inv.errorText && (
        <div className="text-[12px] text-rose-300 bg-rose-950/40 rounded-md p-2.5 border border-rose-900/40 leading-relaxed">
          {inv.errorText}
        </div>
      )}
    </div>
  );
}

function toolIcon(name: string): string {
  const map: Record<string, string> = {
    list_directory: "📂",
    read_text_file: "📖",
    write_text_file: "✏️",
    read_image_file: "🖼️",
    generate_image: "🎨",
    image_to_image: "🔄",
    generate_video: "🎬",
  };
  return map[name] ?? "⚙️";
}

/** 消息气泡 */
export function MessageBubble({
  role,
  text,
  toolInvocations,
  streaming,
  isError,
}: {
  role: "user" | "assistant";
  text: string;
  toolInvocations?: ToolInvocation[];
  streaming?: boolean;
  isError?: boolean;
}) {
  const isUser = role === "user";

  return (
    <div
      className={`flex gap-3 max-w-full ${
        isUser ? "justify-end" : "justify-start"
      }`}
    >
      {!isUser && (
        <div className="shrink-0 w-8 h-8 rounded-full bg-gradient-to-br from-white to-ink-300 text-ink-900 flex items-center justify-center text-xs font-bold self-start mt-1">
          AI
        </div>
      )}

      <div className={`flex-1 ${isUser ? "max-w-[85%]" : "max-w-full"}`}>
        {/* 文字内容 */}
        {text ? (
          <div
            className={`whitespace-pre-wrap break-words rounded-2xl px-3.5 py-2.5 text-[14px] leading-relaxed ${
              isUser
                ? "bg-white text-ink-900 rounded-tr-sm"
                : isError
                ? "bg-rose-950/40 text-rose-100 border border-rose-900/50 rounded-tl-sm"
                : "bg-ink-800/60 text-ink-50 border border-ink-700/40 rounded-tl-sm"
            } ${streaming && !isUser ? "stream-cursor" : ""}`}
          >
            {isUser ? (
              text
            ) : (
              <MarkdownRenderer content={text} />
            )}
          </div>
        ) : null}

        {/* 工具调用卡片 */}
        {toolInvocations && toolInvocations.length > 0 && (
          <div className="mt-1 space-y-1">
            {toolInvocations.map((inv) => (
              <ToolCallCard key={inv.id} inv={inv} />
            ))}
          </div>
        )}
      </div>

      {isUser && (
        <div className="shrink-0 w-8 h-8 rounded-full bg-ink-700 text-ink-100 flex items-center justify-center text-xs font-bold self-start mt-1">
          你
        </div>
      )}
    </div>
  );
}
