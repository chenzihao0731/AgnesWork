import React, { useState } from "react";
import { loadConfig, saveConfig } from "../lib/storage/config";

export function SettingsPanel({
  open,
  onClose,
  onSaved,
}: {
  open: boolean;
  onClose: () => void;
  onSaved: (key: string) => void;
}) {
  const current = loadConfig();
  const [apiKey, setApiKey] = useState(current.apiKey);
  const [saving, setSaving] = useState(false);
  const [justSaved, setJustSaved] = useState(false);

  if (!open) return null;

  const submit = () => {
    setSaving(true);
    saveConfig({ apiKey: apiKey.trim() });
    setTimeout(() => {
      setSaving(false);
      setJustSaved(true);
      onSaved(apiKey.trim());
      setTimeout(() => setJustSaved(false), 1500);
    }, 300);
  };

  return (
    <div
      className="fixed inset-0 z-40 bg-ink-950/70 backdrop-blur-sm flex items-start justify-center pt-20 px-4"
      onClick={onClose}
    >
      <div
        className="glass rounded-2xl w-full max-w-lg p-5 shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between">
          <h2 className="text-lg font-semibold text-ink-50">设置</h2>
          <button className="btn" onClick={onClose}>
            关闭
          </button>
        </div>

        <div className="mt-5 space-y-4">
          <div>
            <label className="block text-xs text-ink-300 mb-1.5">
              Agnes API Key
            </label>
            <input
              type="password"
              className="input font-mono text-[13px]"
              placeholder="agnes-xxxxxxxxxxxxxxxxxxxx"
              value={apiKey}
              onChange={(e) => setApiKey(e.target.value)}
              autoFocus
            />
            <p className="mt-2 text-[11px] text-ink-400 leading-relaxed">
              Key 仅保存在你本地浏览器的 localStorage 中，不会上传到任何服务器。
              获取 Key 请访问{" "}
              <a
                href="https://platform.agnes-ai.com"
                target="_blank"
                rel="noreferrer noopener"
                className="underline hover:text-white"
              >
                platform.agnes-ai.com
              </a>
              。
            </p>
          </div>

          <div className="pt-2 flex items-center justify-end gap-2">
            {justSaved && (
              <span className="text-xs text-emerald-300 mr-2">已保存 ✓</span>
            )}
            <button
              className="btn-primary"
              disabled={saving || !apiKey.trim()}
              onClick={submit}
            >
              {saving ? "保存中..." : "保存并使用"}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
