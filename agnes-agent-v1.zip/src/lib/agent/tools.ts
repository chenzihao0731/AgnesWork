import type { AgnesApiClient } from "../api/agnes";
import type { ToolDefinition } from "../api/types";
import {
  getWorkspace,
  listDirectory,
  readTextFile,
  writeTextFile,
  readImageAsDataUrl,
  isDesktopEnv,
} from "../api/fs";

/** 工具执行上下文 */
export interface ToolRunContext {
  onProgress: (progress: number, status?: string) => void;
  onInfo: (text: string) => void;
}

/** Agent 工具 */
export interface AgentTool {
  definition: ToolDefinition;
  run: (
    args: Record<string, unknown>,
    ctx: ToolRunContext
  ) => Promise<string>; // 返回 tool result（JSON 字符串）
}

// ==================== 工具实现 ====================

function makeTextToImageTool(client: AgnesApiClient): AgentTool {
  return {
    definition: {
      type: "function",
      function: {
        name: "generate_image",
        description:
          "根据文字描述生成一张图片。当用户要求画图、设计配图、生成视觉素材时使用。" +
          "返回一个可访问的图片 URL 和 prompt 摘要。",
        parameters: {
          type: "object",
          properties: {
            prompt: {
              type: "string",
              description:
                "图片描述，必须是英文。建议包含：主体 + 场景 + 视觉风格 + 光照 + 构图。",
            },
            size: {
              type: "string",
              description: '输出尺寸，默认 "1024x768"。可选 "1024x768" / "768x1024" / "1024x1024"',
              default: "1024x768",
            },
          },
          required: ["prompt"],
        },
      },
    },
    async run(args, ctx) {
      const prompt = String(args.prompt || "").trim();
      const size = String(args.size || "1024x768");
      if (!prompt) throw new Error("prompt is required");
      ctx.onInfo(`正在生成: ${prompt.slice(0, 80)}...`);
      const url = await client.textToImage(prompt, size);
      ctx.onProgress(100, "completed");
      return JSON.stringify({
        success: true,
        image_url: url,
        prompt,
        size,
      });
    },
  };
}

function makeTextToVideoTool(client: AgnesApiClient): AgentTool {
  return {
    definition: {
      type: "function",
      function: {
        name: "generate_video",
        description:
          "根据文本描述生成一段视频。视频生成较慢（数十秒），需要等待。" +
          "返回一个可播放的视频 URL。",
        parameters: {
          type: "object",
          properties: {
            prompt: {
              type: "string",
              description:
                "视频描述（英文）。建议包含 [主体] + [动作] + [场景] + [镜头] + [光照] + [风格]。",
            },
            duration_seconds: {
              type: "number",
              description: "时长，默认 5 秒。可选 3 / 5 / 10 / 18。",
              default: 5,
            },
            frame_rate: {
              type: "number",
              description: "帧率，默认 24。",
              default: 24,
            },
            aspect_ratio: {
              type: "string",
              description: '宽高比，默认 "16:9"。可选 "16:9" / "9:16" / "1:1"',
              default: "16:9",
            },
          },
          required: ["prompt"],
        },
      },
    },
    async run(args, ctx) {
      const prompt = String(args.prompt || "").trim();
      const duration = Number(args.duration_seconds) || 5;
      const frameRate = Number(args.frame_rate) || 24;

      // num_frames 必须满足 8n+1 规则
      let numFrames = Math.round(duration * frameRate);
      numFrames = Math.round((numFrames - 1) / 8) * 8 + 1;
      numFrames = Math.max(9, Math.min(441, numFrames));

      let width = 1152;
      let height = 768;
      const ratio = String(args.aspect_ratio || "16:9");
      if (ratio === "9:16") {
        width = 768;
        height = 1152;
      } else if (ratio === "1:1") {
        width = 896;
        height = 896;
      }

      if (!prompt) throw new Error("prompt is required");
      ctx.onInfo(`启动视频任务（${numFrames}帧 @ ${frameRate}fps，${width}x${height}）`);
      const { videoUrl, video_id } = await client.generateVideo(
        { prompt, num_frames: numFrames, frame_rate: frameRate, width, height },
        (progress, status) => ctx.onProgress(progress, status)
      );
      ctx.onProgress(100, "completed");
      return JSON.stringify({
        success: true,
        video_url: videoUrl,
        video_id,
        prompt,
        actual_duration_seconds: +(numFrames / frameRate).toFixed(2),
      });
    },
  };
}

function makeImageToImageTool(client: AgnesApiClient): AgentTool {
  return {
    definition: {
      type: "function",
      function: {
        name: "image_to_image",
        description:
          "基于一张参考图片 + 文本描述，生成一张新图片。参考图片必须是公开可达的 URL。",
        parameters: {
          type: "object",
          properties: {
            prompt: { type: "string", description: "描述如何变化（英文）" },
            reference_image_url: {
              type: "string",
              description: "参考图片的公开 URL（https:// 或 data:image/...）",
            },
            size: {
              type: "string",
              description: '输出尺寸，默认 "1024x768"',
              default: "1024x768",
            },
          },
          required: ["prompt", "reference_image_url"],
        },
      },
    },
    async run(args, ctx) {
      const prompt = String(args.prompt || "").trim();
      const refUrl = String(args.reference_image_url || "").trim();
      const size = String(args.size || "1024x768");
      if (!prompt || !refUrl) throw new Error("缺少参数");
      ctx.onInfo("基于参考图生成新图片...");
      const res = await client.generateImage({
        prompt,
        size,
        image: [refUrl],
        extra_body: { response_format: "url" },
      });
      const first = res.data?.[0];
      if (!first?.url) throw new Error("图片失败");
      ctx.onProgress(100, "completed");
      return JSON.stringify({
        success: true,
        image_url: first.url,
        reference_image_url: refUrl,
        prompt,
      });
    },
  };
}

// ============ 文件系统工具（新增） ============

function makeListDirTool(): AgentTool {
  return {
    definition: {
      type: "function",
      function: {
        name: "list_directory",
        description:
          "列出工作目录下的文件和子目录。不传 path 则列出 workspace 根目录。" +
          "这是 Agent 查看本地文件结构的唯一入口，先调用它再决定读哪个文件。",
        parameters: {
          type: "object",
          properties: {
            path: {
              type: "string",
              description: "相对 workspace 的子目录路径。留空表示根目录。",
            },
          },
          required: [],
        },
      },
    },
    async run(args, ctx) {
      const path = args.path ? String(args.path) : undefined;
      ctx.onInfo(`列出目录: ${path || "(workspace 根)"}`);
      const entries = await listDirectory(path);
      ctx.onProgress(100, "completed");
      return JSON.stringify({
        success: true,
        workspace: await getWorkspace().catch(() => ""),
        path: path || "./",
        entries: entries.slice(0, 100),
        count: entries.length,
      });
    },
  };
}

function makeReadTextTool(): AgentTool {
  return {
    definition: {
      type: "function",
      function: {
        name: "read_text_file",
        description:
          "读取工作目录中的文本文件，用于分析代码、读取配置、总结文档内容。" +
          "对于大文件请设置 max_bytes 避免超出上下文限制。",
        parameters: {
          type: "object",
          properties: {
            path: {
              type: "string",
              description: "文件路径（相对 workspace 或绝对路径，但必须在 workspace 内）",
            },
            max_bytes: {
              type: "number",
              description: "最大读取字节数（建议 8000~32000）；不传则读取全部",
            },
          },
          required: ["path"],
        },
      },
    },
    async run(args, ctx) {
      const path = String(args.path || "").trim();
      if (!path) throw new Error("path is required");
      const maxBytes = args.max_bytes ? Number(args.max_bytes) : undefined;
      ctx.onInfo(`读取文件: ${path}${maxBytes ? `（前${maxBytes}字节）` : ""}`);
      const content = await readTextFile(path, maxBytes);
      ctx.onProgress(100, "completed");
      return JSON.stringify({
        success: true,
        path,
        bytes: content.length,
        content,
      });
    },
  };
}

function makeWriteTextTool(): AgentTool {
  return {
    definition: {
      type: "function",
      function: {
        name: "write_text_file",
        description:
          "把内容写入工作目录下的文本文件。用于：保存代码、写报告、导出对话记录、" +
          "生成 Markdown 文档等。相同路径会覆盖，请谨慎！",
        parameters: {
          type: "object",
          properties: {
            path: {
              type: "string",
              description: "目标文件路径（相对 workspace 或绝对路径，必须在 workspace 内）",
            },
            content: { type: "string", description: "要写入的文本内容" },
          },
          required: ["path", "content"],
        },
      },
    },
    async run(args, ctx) {
      const path = String(args.path || "").trim();
      const content = String(args.content ?? "");
      if (!path) throw new Error("path is required");
      ctx.onInfo(`写入文件: ${path}（${content.length} 字符）`);
      const actualPath = await writeTextFile(path, content);
      ctx.onProgress(100, "completed");
      return JSON.stringify({
        success: true,
        path: actualPath,
        bytes: content.length,
      });
    },
  };
}

function makeReadImageTool(): AgentTool {
  return {
    definition: {
      type: "function",
      function: {
        name: "read_image_file",
        description:
          "读取工作目录中的图片文件为 base64 data URL，返回的值可以交给" +
          "多模态模型分析图片内容（识别图表、截图识别文字、描述图片等）。" +
          "注意：文件体积越大，token 消耗越多。",
        parameters: {
          type: "object",
          properties: {
            path: { type: "string", description: "图片路径（相对 workspace）" },
          },
          required: ["path"],
        },
      },
    },
    async run(args, ctx) {
      const path = String(args.path || "").trim();
      if (!path) throw new Error("path is required");
      ctx.onInfo(`读取图片: ${path}`);
      const dataUrl = await readImageAsDataUrl(path);
      ctx.onProgress(100, "completed");
      return JSON.stringify({
        success: true,
        path,
        image_data_url: dataUrl,
        preview_hint:
          "此 URL 可以直接作为消息内容中的 image_url 交给多模态模型分析",
      });
    },
  };
}

// ==================== registry ====================

export function buildToolRegistry(client: AgnesApiClient): Record<string, AgentTool> {
  const tools = [
    makeTextToImageTool(client),
    makeTextToVideoTool(client),
    makeImageToImageTool(client),
    makeListDirTool(),
    makeReadTextTool(),
    makeWriteTextTool(),
    makeReadImageTool(),
  ];
  return Object.fromEntries(tools.map((t) => [t.definition.function.name, t]));
}

export function getToolDefinitions(
  registry: Record<string, AgentTool>
): ToolDefinition[] {
  return Object.values(registry).map((t) => t.definition);
}

export function hasFileTools(): boolean {
  return isDesktopEnv();
}
