import type { AgnesApiClient } from "../api/agnes";
import type {
  ChatMessage,
  ToolCall,
  ChatCompletionChunk,
} from "../api/types";
import { buildToolRegistry, getToolDefinitions, type AgentTool } from "./tools";

/** UI 层消息（比 API message 多一些元数据） */
export interface UIChatMessage {
  id: string;
  role: "user" | "assistant" | "system";
  text: string;          // 累积的文本（流式）
  toolInvocations: ToolInvocation[];  // 本轮调用过的工具
  streaming: boolean;    // 是否正在流式输出
  isError?: boolean;
  createdAt: number;
}

/** UI 层记录的工具调用 */
export interface ToolInvocation {
  id: string;
  name: string;
  args: Record<string, unknown>;
  status: "running" | "success" | "error";
  progress: number;
  infoText: string;
  resultJson?: string;
  errorText?: string;
  /** 可视化产物（图/视频 URL） */
  artifacts: Array<{ kind: "image" | "video"; url: string }>;
}

/** 给流式回调的数据结构 */
export interface AgentStreamCallbacks {
  onMessageUpdate: (msgId: string, partial: Partial<UIChatMessage>) => void;
  onNewMessage: (msg: UIChatMessage) => string; // 返回消息 id
  onStatus: (text: string) => void;
}

/** Agent 核心：编排 LLM <-> 工具的调用循环 */
export class AgentEngine {
  private client: AgnesApiClient;
  private registry: Record<string, AgentTool>;
  private toolDefs: ReturnType<typeof getToolDefinitions>;
  private aborted = false;

  constructor(client: AgnesApiClient) {
    this.client = client;
    this.registry = buildToolRegistry(client);
    this.toolDefs = getToolDefinitions(this.registry);
  }

  requestStop() {
    this.aborted = true;
  }

  private systemPrompt(): string {
    return (
      "你是 Agnes Agent，一个运行在用户桌面上的多模态 AI 助手。\n\n" +
      "你的能力（通过 tool_calling 使用）：\n" +
      "1. 调用 generate_image：根据描述生成图片\n" +
      "2. 调用 generate_video：根据描述生成视频\n" +
      "3. 调用 image_to_image：基于参考图片生成新图片\n" +
      "4. 调用 list_directory：查看工作目录结构（了解本地有什么）\n" +
      "5. 调用 read_text_file：读取工作目录中的文本文件（代码 / 文档 / 配置）\n" +
      "6. 调用 write_text_file：把内容写入工作目录下的文件\n" +
      "7. 调用 read_image_file：把本地图片转成 base64 URL，让多模态模型看见图片\n\n" +
      "行为准则：\n" +
      "- 当用户要求画图 / 做视频 / 读取本地文件 / 写入文件 时，主动调用对应工具。\n" +
      "- 不确定路径时，先调用 list_directory 查看结构，再决定下一步。\n" +
      "- 文件工具的参数必须在工作目录内（由用户选定）。不要硬编码路径。\n" +
      "- 如果调用 read_image_file 成功：把返回的 image_data_url 当作图片内容理解。" +
      " 下一轮对话中，把该 data:image/... URL 与文本一起输入以便你分析图片内容。\n" +
      "- 所有 image / video 生成工具的 prompt 请使用英文以获得更好效果。\n" +
      "- 调用工具后，根据 tool result 用中文给用户简洁的总结，并把图片/视频 URL 直接展示给用户。\n" +
      "- 不要虚构不存在的工具。"
    );
  }

  /** 主函数：接收用户输入，驱动整个循环。返回最终的 assistant 文本。 */
  async run(
    userInput: string,
    conversationHistory: UIChatMessage[],
    cb: AgentStreamCallbacks
  ): Promise<void> {
    this.aborted = false;

    // 1. 构造发送给 LLM 的消息数组
    const messages: ChatMessage[] = [
      { role: "system", content: this.systemPrompt() },
    ];

    // 把历史转为 API message（把 tool 调用转成 tool_calls + tool 消息）
    for (const m of conversationHistory) {
      if (m.isError) continue;
      if (m.role === "user") {
        messages.push({ role: "user", content: m.text });
      } else if (m.role === "assistant") {
        // 有 tool 调用 -> 需要拆成：assistant（tool_calls）+ 多条 tool 消息
        if (m.toolInvocations.length > 0) {
          const tool_calls: ToolCall[] = m.toolInvocations.map((inv) => ({
            id: inv.id,
            type: "function",
            function: {
              name: inv.name,
              arguments: JSON.stringify(inv.args),
            },
          }));
          messages.push({
            role: "assistant",
            content: m.text,
            tool_calls,
          });
          // 每条 tool_call 后追加一条 tool 结果消息
          for (const inv of m.toolInvocations) {
            messages.push({
              role: "tool",
              tool_call_id: inv.id,
              content:
                inv.resultJson ||
                JSON.stringify({
                  error: inv.errorText || "tool failed",
                }),
            });
          }
        } else {
          messages.push({ role: "assistant", content: m.text });
        }
      }
    }

    // 追加本次用户输入
    messages.push({ role: "user", content: userInput });

    cb.onStatus("思考中...");

    // 2. 循环：LLM 可能多次请求工具调用，最多 5 轮防死循环
    const maxRounds = 5;
    let currentAssistantId: string | null = null;
    const currentToolInvs: ToolInvocation[] = [];
    let accumulatedText = "";

    for (let round = 0; round < maxRounds; round++) {
      if (this.aborted) break;

      const toolCalls: ToolCall[] = [];
      let roundText = "";
      let firstChunkForRound = true;

      cb.onStatus(round === 0 ? "正在回复..." : "继续思考...");

      // 流式调用 LLM
      try {
        for await (const chunk of this.client.chatStream({
          messages,
          tools: this.toolDefs,
          tool_choice: "auto",
          temperature: 0.6,
          max_tokens: 1500,
        })) {
          if (this.aborted) break;
          const delta = chunk.choices?.[0]?.delta;
          if (!delta) continue;

          // 文本增量
          if (typeof delta.content === "string" && delta.content) {
            roundText += delta.content;
            accumulatedText += delta.content;

            // 首次收到文本时创建 assistant 消息
            if (firstChunkForRound && roundText.length > 0) {
              currentAssistantId = this.ensureAssistantMessage(
                currentAssistantId,
                accumulatedText,
                currentToolInvs,
                cb
              );
              firstChunkForRound = false;
            } else if (currentAssistantId) {
              cb.onMessageUpdate(currentAssistantId, {
                text: accumulatedText,
              });
            }
          }

          // tool_calls
          if (delta.tool_calls && delta.tool_calls.length > 0) {
            for (const tc of delta.tool_calls) {
              const idx = tc.index ?? 0;
              while (toolCalls.length <= idx) {
                toolCalls.push({
                  id: "",
                  type: "function",
                  function: { name: "", arguments: "" },
                });
              }
              if (tc.id) toolCalls[idx].id = tc.id;
              if (tc.function?.name)
                toolCalls[idx].function.name += tc.function.name;
              if (tc.function?.arguments)
                toolCalls[idx].function.arguments += tc.function.arguments;
            }
          }
        }
      } catch (err) {
        const msg = (err as Error).message || String(err);
        if (!currentAssistantId) {
          currentAssistantId = cb.onNewMessage({
            id: "",
            role: "assistant",
            text: `⚠️ API 调用失败: ${msg}`,
            toolInvocations: [],
            streaming: false,
            isError: true,
            createdAt: Date.now(),
          });
        } else {
          cb.onMessageUpdate(currentAssistantId, {
            text: accumulatedText + `\n\n⚠️ 出错了: ${msg}`,
            streaming: false,
            isError: true,
          });
        }
        cb.onStatus("已停止");
        return;
      }

      if (this.aborted) break;

      // 本轮无工具调用 -> 结束循环
      if (toolCalls.length === 0) {
        // 如果 assistant 消息还不存在（纯工具调用流程时可能发生），创建一条空的
        if (!currentAssistantId) {
          currentAssistantId = this.ensureAssistantMessage(
            null,
            accumulatedText,
            currentToolInvs,
            cb
          );
        }
        if (currentAssistantId) {
          cb.onMessageUpdate(currentAssistantId, {
            streaming: false,
            text: accumulatedText,
          });
        }
        cb.onStatus("完成");
        return;
      }

      // 3. 有工具调用 -> 先把"正在调用工具"的状态反映到 UI
      cb.onStatus(`准备调用 ${toolCalls.length} 个工具...`);

      // 如果还没有 assistant 消息，先创建一个（展示 tool-calling 状态）
      if (!currentAssistantId) {
        currentAssistantId = this.ensureAssistantMessage(
          null,
          accumulatedText,
          currentToolInvs,
          cb
        );
      }

      // 4. 执行工具调用（可以并行）
      const runResults: Array<{
        toolCallId: string;
        toolName: string;
        toolArgs: Record<string, unknown>;
        resultJson: string;
        error?: string;
        inv: ToolInvocation;
      }> = [];

      for (const tc of toolCalls) {
        const tool = this.registry[tc.function.name];
        if (!tool) {
          // LLM 调用了一个我们没注册的工具 -> 把错误告诉它
          const errMsg = `Unknown tool: ${tc.function.name}`;
          const inv: ToolInvocation = {
            id: tc.id || `unknown_${Date.now()}`,
            name: tc.function.name || "unknown",
            args: {},
            status: "error",
            progress: 0,
            infoText: errMsg,
            artifacts: [],
          };
          currentToolInvs.push(inv);
          runResults.push({
            toolCallId: inv.id,
            toolName: inv.name,
            toolArgs: {},
            resultJson: JSON.stringify({ error: errMsg }),
            error: errMsg,
            inv,
          });
          if (currentAssistantId)
            cb.onMessageUpdate(currentAssistantId, {
              toolInvocations: [...currentToolInvs],
            });
          continue;
        }

        // 解析参数
        let toolArgs: Record<string, unknown> = {};
        try {
          toolArgs = JSON.parse(tc.function.arguments || "{}");
        } catch {
          // 解析失败，用空对象，让工具自己检查
        }

        const inv: ToolInvocation = {
          id: tc.id || `${tc.function.name}_${Date.now()}`,
          name: tc.function.name,
          args: toolArgs,
          status: "running",
          progress: 0,
          infoText: "启动中...",
          artifacts: [],
        };
        currentToolInvs.push(inv);
        if (currentAssistantId)
          cb.onMessageUpdate(currentAssistantId, {
            toolInvocations: [...currentToolInvs],
          });

        try {
          cb.onStatus(`执行: ${tc.function.name}`);
          const resultJson = await tool.run(toolArgs, {
            onProgress: (p, s) => {
              inv.progress = p;
              if (s) inv.infoText = s;
              if (currentAssistantId)
                cb.onMessageUpdate(currentAssistantId, {
                  toolInvocations: [...currentToolInvs],
                });
            },
            onInfo: (text) => {
              inv.infoText = text;
              if (currentAssistantId)
                cb.onMessageUpdate(currentAssistantId, {
                  toolInvocations: [...currentToolInvs],
                });
            },
          });

          // 解析产物（图片/视频 URL）
          try {
            const parsed = JSON.parse(resultJson);
            // generate_image / image_to_image
            if (parsed.image_url) {
              inv.artifacts.push({ kind: "image", url: parsed.image_url });
            }
            // generate_video
            if (parsed.video_url) {
              inv.artifacts.push({ kind: "video", url: parsed.video_url });
            }
            // read_image_file：把本地图片转为 data URL，让 UI 预览 & 让下一轮 LLM 可见
            if (parsed.image_data_url) {
              inv.artifacts.push({ kind: "image", url: parsed.image_data_url });
            }
          } catch {
            // ignore parse
          }

          inv.status = "success";
          inv.progress = 100;
          inv.resultJson = resultJson;
          runResults.push({
            toolCallId: inv.id,
            toolName: inv.name,
            toolArgs,
            resultJson,
            inv,
          });
        } catch (e) {
          const errText = (e as Error).message || String(e);
          inv.status = "error";
          inv.errorText = errText;
          inv.resultJson = JSON.stringify({ error: errText });
          runResults.push({
            toolCallId: inv.id,
            toolName: inv.name,
            toolArgs,
            resultJson: inv.resultJson,
            error: errText,
            inv,
          });
        }
        if (currentAssistantId)
          cb.onMessageUpdate(currentAssistantId, {
            toolInvocations: [...currentToolInvs],
          });
      }

      // 5. 把 tool_calls 追加到 LLM messages，并追加 tool 结果，
      //    然后让 LLM 基于 tool result 再生成一次回复
      messages.push({
        role: "assistant",
        content: roundText,
        tool_calls: toolCalls.map((tc) => ({
          id: currentToolInvs[toolCalls.indexOf(tc)]?.id || tc.id,
          type: "function",
          function: tc.function,
        })),
      });

      for (const r of runResults) {
        messages.push({
          role: "tool",
          tool_call_id: r.toolCallId,
          content: r.resultJson,
        });
      }

      // 继续下一轮循环：LLM 会拿到 tool result 并生成总结文本
    }

    // 超过最大轮次，收尾
    if (currentAssistantId) {
      cb.onMessageUpdate(currentAssistantId, {
        text: accumulatedText,
        streaming: false,
        toolInvocations: currentToolInvs,
      });
    }
    cb.onStatus("完成");
  }

  /** 确保存在一条 assistant 消息，并返回其 id */
  private ensureAssistantMessage(
    existingId: string | null,
    text: string,
    invs: ToolInvocation[],
    cb: AgentStreamCallbacks
  ): string {
    if (existingId) {
      cb.onMessageUpdate(existingId, { text, toolInvocations: [...invs] });
      return existingId;
    }
    const newMsg: UIChatMessage = {
      id: "",
      role: "assistant",
      text,
      toolInvocations: invs,
      streaming: true,
      createdAt: Date.now(),
    };
    return cb.onNewMessage(newMsg);
  }
}

/** 把 API chunk 里 tool_calls 的索引字段补充到类型里（我们在运行时需要） */
declare module "../api/types" {
  interface ToolCall {
    index?: number;
  }
}
