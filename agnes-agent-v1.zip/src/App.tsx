import React, { useEffect, useMemo, useRef, useState } from "react";
import { AgnesApiClient } from "./lib/api/agnes";
import {
  AgentEngine,
  type UIChatMessage,
  type ToolInvocation,
} from "./lib/agent/agent";
import {
  createEmptyConversation,
  loadAllConversations,
  loadConfig,
  saveConfig,
  saveConversation,
  type Conversation,
} from "./lib/storage/config";
import { MessageBubble } from "./components/MessageBubble";
import { SettingsPanel } from "./components/SettingsPanel";
import {
  getWorkspace,
  isDesktopEnv,
  pickDirectoryDialog,
  setWorkspace,
  pickFileDialog,
  readTextFile,
} from "./lib/api/fs";

// ---- helper ----
function makeId(prefix = "m"): string {
  return `${prefix}_${Date.now().toString(36)}_${Math.random()
    .toString(36)
    .slice(2, 7)}`;
}

function summarize(text: string, max = 24): string {
  const t = text.replace(/\s+/g, " ").trim();
  return t.length > max ? t.slice(0, max) + "…" : t;
}

export default function App() {
  const [apiKey, setApiKey] = useState<string>("");
  const [showSettings, setShowSettings] = useState(false);
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [activeId, setActiveId] = useState<string>("");
  const [messages, setMessages] = useState<UIChatMessage[]>([]);
  const [input, setInput] = useState<string>("");
  const [isRunning, setIsRunning] = useState(false);
  const [status, setStatus] = useState<string>("");
  const [workspace, setWorkSpace] = useState<string>("");
  const [attachments, setAttachments] = useState<
    Array<{ path: string; text?: string; imageDataUrl?: string }>
  >([]);

  const engineRef = useRef<AgentEngine | null>(null);
  const scrollRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  // ---------- 初始化 ----------
  useEffect(() => {
    const cfg = loadConfig();
    setApiKey(cfg.apiKey);
    if (cfg.apiKey) {
      engineRef.current = new AgentEngine(
        new AgnesApiClient(cfg.apiKey)
      );
    }

    // 会话
    const convs = loadAllConversations();
    if (convs.length === 0) {
      const fresh = createEmptyConversation("新对话");
      setConversations([fresh]);
      setActiveId(fresh.id);
    } else {
      setConversations(convs);
      // 用 config 中的 activeId 做高亮，没有则取最新
      const active =
        cfg.activeConversationId &&
        convs.find((c) => c.id === cfg.activeConversationId)
          ? cfg.activeConversationId
          : convs[0].id;
      setActiveId(active);
    }

    // workspace
    if (isDesktopEnv()) {
      getWorkspace()
        .then((p) => setWorkSpace(p))
        .catch(() => { /* ignore */ });
    }
  }, []);

  // ---------- 当切换会话 -> 加载对应消息 ----------
  useEffect(() => {
    if (!activeId || conversations.length === 0) return;
    const conv = conversations.find((c) => c.id === activeId);
    if (!conv) return;
    const uiMsgs: UIChatMessage[] = conv.messages.map((m) => ({
      id: makeId(),
      role: m.role,
      text: m.text,
      toolInvocations: [],
      streaming: false,
      createdAt: m.createdAt,
    }));
    setMessages(uiMsgs);
    // 更新 config.activeConversationId
    const cfg = loadConfig();
    if (cfg.activeConversationId !== activeId) {
      saveConfig({ ...cfg, activeConversationId: activeId });
    }
  }, [activeId, conversations.length]);

  // 自动滚到底部
  useEffect(() => {
    const el = scrollRef.current;
    if (!el) return;
    el.scrollTop = el.scrollHeight;
  }, [messages, status]);

  // textarea 自适应高度
  useEffect(() => {
    const ta = textareaRef.current;
    if (!ta) return;
    ta.style.height = "auto";
    ta.style.height = Math.min(ta.scrollHeight, 220) + "px";
  }, [input]);

  const hasKey = useMemo(() => apiKey.trim().length > 0, [apiKey]);
  const activeConv = conversations.find((c) => c.id === activeId);

  // ---------- 保存当前会话 ----------
  function persistActiveConversation(titleOverride?: string) {
    const conv = conversations.find((c) => c.id === activeId);
    if (!conv) return;
    const persistedText = messages
      .filter((m) => !m.isError && !m.streaming)
      .map((m) => ({
        role: m.role,
        text: m.text.slice(0, 20000),
        createdAt: m.createdAt,
      }));
    const title =
      titleOverride ||
      (conv.title !== "新对话"
        ? conv.title
        : messages.find((m) => m.role === "user")?.text
        ? summarize(messages.find((m) => m.role === "user")!.text, 24)
        : "新对话");
    const updated: Conversation = {
      ...conv,
      title,
      messages: persistedText,
      updatedAt: Date.now(),
    };
    saveConversation(updated);
    setConversations((prev) =>
      prev
        .map((c) => (c.id === activeId ? updated : c))
        .sort((a, b) => b.updatedAt - a.updatedAt)
    );
  }

  useEffect(() => {
    // 有变更时，延迟保存（debounce）
    if (messages.length === 0) return;
    const t = setTimeout(() => {
      persistActiveConversation();
    }, 800);
    return () => clearTimeout(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [messages]);

  // ---------- 会话操作 ----------
  function handleNewConversation() {
    const fresh = createEmptyConversation("新对话");
    setConversations((prev) => [fresh, ...prev].sort((a, b) => b.updatedAt - a.updatedAt));
    setActiveId(fresh.id);
    setMessages([]);
  }

  function handleDeleteConversation(id: string) {
    if (!confirm("删除该会话？")) return;
    // 直接删除（通过 storage 结构，我们在 localStorage 中没有“单条删除” helper，所以做一个全量的重新保存）
    // 这里复用我们已经有的 saveConversation / loadAllConversations 结构：
    // 简化：我们把该 id 的 conversations 从 React state 删去，然后对其他会话重新 saveConversation。
    // 这里实现一个简单 helper：直接在 localStorage 里找对应 key 删。
    try {
      localStorage.removeItem("agnes.agent.conv.v2:" + id);
    } catch {}
    const next = conversations.filter((c) => c.id !== id);
    if (next.length === 0) {
      const fresh = createEmptyConversation("新对话");
      setConversations([fresh]);
      setActiveId(fresh.id);
      setMessages([]);
      return;
    }
    setConversations(next);
    if (activeId === id) {
      setActiveId(next[0].id);
    }
  }

  function handleRenameConversation(id: string) {
    const conv = conversations.find((c) => c.id === id);
    if (!conv) return;
    const newTitle = prompt("重命名会话", conv.title);
    if (!newTitle) return;
    const updated = { ...conv, title: newTitle.trim(), updatedAt: Date.now() };
    saveConversation(updated);
    setConversations((prev) =>
      prev.map((c) => (c.id === id ? updated : c))
    );
  }

  // ---------- 工作目录 ----------
  async function handlePickWorkspace() {
    try {
      const path = await pickDirectoryDialog();
      await setWorkspace(path);
      setWorkSpace(path);
    } catch (e: any) {
      alert("选择工作目录失败: " + (e?.message || String(e)));
    }
  }

  // ---------- 附件上传（纯文本形式：把本地文件读成文本，添加到用户输入中） ----------
  async function handleAttachFile() {
    try {
      const path = await pickFileDialog();
      // 尝试读取文本内容；图片由 agent 自己调用 read_image_file。
      let text: string | undefined;
      try {
        text = await readTextFile(path, 12000);
      } catch {
        text = undefined;
      }
      setAttachments((prev) => [
        ...prev,
        { path, text: text?.slice(0, 2000) },
      ]);
    } catch (e: any) {
      alert("选择文件失败: " + (e?.message || String(e)));
    }
  }

  // ---------- 发送消息 ----------
  async function onSend() {
    const userText = input.trim();
    // 允许只上传附件不写文字：此时用描述文字
    const finalUserText =
      userText ||
      (attachments.length > 0
        ? `[附件] 请分析这些文件：` + attachments.map((a) => a.path).join(", ")
        : "");
    if (!finalUserText.trim()) return;
    if (!hasKey) {
      setShowSettings(true);
      return;
    }
    if (!engineRef.current) {
      engineRef.current = new AgentEngine(new AgnesApiClient(apiKey));
    }

    // 构造用户输入（含附件内容）
    let constructedUserInput = userText;
    if (attachments.length > 0) {
      const preamble =
        "我附上以下本地文件（我已经读取了文本内容）：\n\n";
      const blocks = attachments
        .map((a, i) => {
          const body = a.text
            ? `\`\`\`\n${a.text}\n\`\`\``
            : "[非文本文件，请使用 read_image_file 或 list_directory 等工具读取]";
          return `【文件 ${i + 1}：${a.path}】\n${body}`;
        })
        .join("\n\n");
      constructedUserInput =
        (userText ? userText + "\n\n" : "") + preamble + blocks;
    }

    // 1. 推入一条用户消息
    const userMsg: UIChatMessage = {
      id: makeId(),
      role: "user",
      text: userText || finalUserText,
      toolInvocations: [],
      streaming: false,
      createdAt: Date.now(),
    };
    const startingMessages = [...messages, userMsg];
    setMessages(startingMessages);
    setIsRunning(true);
    setStatus("思考中...");
    setAttachments([]);
    setInput("");

    // 2. agent 运行
    const engine = engineRef.current!;
    try {
      await engine.run(constructedUserInput, messages, {
        onStatus: setStatus,
        onNewMessage: (msg) => {
          const id = makeId();
          setMessages((prev) => [...prev, { ...msg, id }]);
          return id;
        },
        onMessageUpdate: (msgId, partial) => {
          setMessages((prev) =>
            prev.map((m) =>
              m.id === msgId
                ? {
                    ...m,
                    text: partial.text ?? m.text,
                    toolInvocations:
                      (
                        partial as { toolInvocations?: ToolInvocation[] }
                      ).toolInvocations ?? m.toolInvocations,
                    streaming:
                      (partial as { streaming?: boolean }).streaming ??
                      m.streaming,
                  }
                : m
            )
          );
        },
      });
    } catch (e: any) {
      setMessages((prev) => [
        ...prev,
        {
          id: makeId(),
          role: "assistant",
          text: "⚠️ 出错：" + (e?.message || String(e)),
          toolInvocations: [],
          streaming: false,
          isError: true,
          createdAt: Date.now(),
        },
      ]);
    }

    // 收尾：最后一条 assistant 消息设为 streaming=false
    setMessages((prev) =>
      prev.map((m) =>
        m.role === "assistant" && m.streaming ? { ...m, streaming: false } : m
      )
    );
    setIsRunning(false);
    setStatus("");

    // 自动标题：只有"新对话"才改标题
    const firstUserMsg = (startingMessages).find((m) => m.role === "user");
    if (activeConv?.title === "新对话" && firstUserMsg) {
      generateTitle(firstUserMsg.text, constructedUserInput);
    }
  }

  /** 用 LLM 生成会话标题 */
  async function generateTitle(userMsg: string, fullInput: string) {
    if (!apiKey) return;
    try {
      const client = new AgnesApiClient(apiKey);
      const prompt =
        `根据用户的第一条消息，生成一个简短的中文会话标题（不超过20个字，不要引号）。\n` +
        `用户消息：${userMsg.slice(0, 200)}\n` +
        `标题：` ;

      const res = await client.chat({
        messages: [{ role: "user", content: prompt }],
        temperature: 0.3,
        max_tokens: 30,
      });
      const rawTitle =
        res.choices?.[0]?.message?.content?.trim() ?? "";
      // 去掉可能的引号
      const title = rawTitle.replace(/^[""]+|[""]+$/g, "").slice(0, 24);
      if (title) {
        persistActiveConversation(title);
      }
    } catch {
      // 生成失败不影响主流程
    }
  }

  function onStop() {
    engineRef.current?.requestStop();
    setIsRunning(false);
    setStatus("已停止");
  }

  function onKeySaved(key: string) {
    setApiKey(key);
    engineRef.current = new AgentEngine(new AgnesApiClient(key));
    setShowSettings(false);
  }

  // ---------- 键盘 ----------
  function onKeyDown(e: React.KeyboardEvent<HTMLTextAreaElement>) {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      onSend();
    }
  }

  // ---------- UI ----------
  return (
    <div className="h-full w-full flex bg-gradient-to-b from-ink-950 to-black text-ink-50">
      {/* 左侧：会话管理 */}
      <aside className="shrink-0 w-64 border-r border-ink-800/80 flex flex-col bg-ink-950/60">
        <div className="p-3 border-b border-ink-800/80 flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-white to-ink-300 text-ink-900 text-xs font-bold flex items-center justify-center shadow">
            AI
          </div>
          <div className="text-sm font-semibold grad-text">Agnes Agent</div>
        </div>

        <div className="p-2 flex gap-2">
          <button
            className="btn flex-1 !py-1.5 text-xs"
            onClick={handleNewConversation}
            title="新建对话"
          >
            + 新对话
          </button>
        </div>

        <div className="flex-1 overflow-y-auto scrollable px-2 pb-2 space-y-1">
          {conversations.map((c) => (
            <div
              key={c.id}
              onClick={() => setActiveId(c.id)}
              className={
                "group cursor-pointer rounded-lg px-2 py-2 text-[13px] flex items-start gap-2 border transition-colors " +
                (c.id === activeId
                  ? "bg-ink-800/80 border-ink-600/60 text-white"
                  : "bg-transparent border-transparent hover:bg-ink-800/50 text-ink-200")
              }
            >
              <div className="flex-1 min-w-0">
                <div className="truncate font-medium">
                  {c.title || "新对话"}
                </div>
                <div className="text-[10px] text-ink-400 mt-0.5">
                  {c.messages.length} 条 ·{" "}
                  {new Date(c.updatedAt).toLocaleString("zh-CN", {
                    month: "2-digit",
                    day: "2-digit",
                    hour: "2-digit",
                    minute: "2-digit",
                  })}
                </div>
              </div>
              <div className="hidden group-hover:flex shrink-0 items-center gap-1 text-[11px] text-ink-400 hover:text-white">
                <button
                  title="重命名"
                  onClick={(e) => {
                    e.stopPropagation();
                    handleRenameConversation(c.id);
                  }}
                  className="hover:underline"
                >
                  改名
                </button>
                <button
                  title="删除"
                  onClick={(e) => {
                    e.stopPropagation();
                    handleDeleteConversation(c.id);
                  }}
                  className="hover:text-rose-300 hover:underline"
                >
                  删
                </button>
              </div>
            </div>
          ))}
        </div>

        {/* 底部状态：workspace + 设置 */}
        <div className="p-3 border-t border-ink-800/80 space-y-2">
          <div className="text-[11px] text-ink-400">
            {isDesktopEnv() ? (
              <>
                工作目录：
                {workspace ? (
                  <button
                    onClick={handlePickWorkspace}
                    className="underline text-ink-200 hover:text-white break-all text-left"
                    title="点击更换工作目录"
                  >
                    {workspace}
                  </button>
                ) : (
                  <button
                    onClick={handlePickWorkspace}
                    className="underline text-amber-300 hover:text-white"
                  >
                    未设置（点击选择）
                  </button>
                )}
              </>
            ) : (
              <>运行在桌面端可启用文件工具（当前为浏览器模式）</>
            )}
          </div>
          <div className="flex items-center justify-between gap-2">
            <button className="btn !py-1.5 text-xs" onClick={() => setShowSettings(true)}>
              设置
            </button>
            <span
              className={
                "text-[11px] rounded-full px-2 py-1 border " +
                (hasKey
                  ? "text-emerald-300 bg-emerald-950/30 border-emerald-900/40"
                  : "text-amber-300 bg-amber-950/30 border-amber-900/40")
              }
            >
              {hasKey ? "● 已连接" : "○ 未配置 Key"}
            </span>
          </div>
          {status && (
            <div className="text-[11px] text-ink-300 bg-ink-800/40 border border-ink-700/50 rounded-lg px-2 py-1.5">
              {status}
            </div>
          )}
        </div>
      </aside>

      {/* 主聊天区 */}
      <main className="flex-1 flex flex-col min-w-0">
        <header className="shrink-0 px-5 py-3 border-b border-ink-800/80 flex items-center justify-between">
          <div className="text-sm text-ink-200 truncate">
            {activeConv?.title || "新对话"}
            <span className="text-ink-500 ml-2">
              · {messages.filter((m) => m.role === "user").length} 条用户提问
            </span>
          </div>
          <div className="flex items-center gap-2">
            <button
              className="btn !py-1.5 text-xs"
              onClick={() => {
                if (confirm("清空当前对话消息？（会话本身保留）")) {
                  setMessages([]);
                  if (activeId) {
                    const conv = conversations.find((c) => c.id === activeId);
                    if (conv) {
                      const cleared = { ...conv, messages: [], updatedAt: Date.now() };
                      saveConversation(cleared);
                      setConversations((prev) =>
                        prev.map((c) => (c.id === activeId ? cleared : c))
                      );
                    }
                  }
                }
              }}
            >
              清空
            </button>
          </div>
        </header>

        {/* 消息滚动区 */}
        <div ref={scrollRef} className="flex-1 min-h-0 overflow-y-auto scrollable">
          <div className="max-w-3xl mx-auto px-4 py-6 space-y-4">
            {messages.length === 0 && (
              <div className="mt-6 mb-2">
                <div className="glass rounded-2xl p-6">
                  <div className="text-base font-semibold grad-text mb-1.5">
                    你好，我是 Agnes Agent
                  </div>
                  <div className="text-sm text-ink-300 leading-relaxed space-y-1">
                    <p>我可以：</p>
                    <ul className="list-disc pl-5 space-y-0.5 text-ink-200">
                      <li>与你多轮对话聊天；</li>
                      <li>调用 AI 生成图片 / 视频；</li>
                      <li>
                        在桌面端时，查看并读写你本地工作目录中的文件（代码、文档、图片）。
                      </li>
                    </ul>
                  </div>
                  <div className="mt-4 grid grid-cols-1 sm:grid-cols-2 gap-2 text-[13px]">
                    <button
                      onClick={() =>
                        setInput("帮我画一张日落时的城市天际线，电影感，1024x768")
                      }
                      className="text-left rounded-lg px-3 py-2 bg-ink-800/60 hover:bg-ink-700/60 border border-ink-700/60 text-ink-200"
                    >
                      示例：生成图片
                    </button>
                    <button
                      onClick={() =>
                        setInput(
                          "先查看工作目录结构，再给我读一个 README 并总结（若有）"
                        )
                      }
                      className="text-left rounded-lg px-3 py-2 bg-ink-800/60 hover:bg-ink-700/60 border border-ink-700/60 text-ink-200"
                    >
                      示例：查看工作目录
                    </button>
                    <button
                      onClick={() =>
                        setInput(
                          "帮我做一个 5 秒的视频：一只猫在夕阳海滩上行走，电影感运镜"
                        )
                      }
                      className="text-left rounded-lg px-3 py-2 bg-ink-800/60 hover:bg-ink-700/60 border border-ink-700/60 text-ink-200"
                    >
                      示例：生成视频
                    </button>
                    <button
                      onClick={() =>
                        setInput(
                          "请写一段关于多模态 AI 的介绍文字，并保存到 workspace 的 intro.md"
                        )
                      }
                      className="text-left rounded-lg px-3 py-2 bg-ink-800/60 hover:bg-ink-700/60 border border-ink-700/60 text-ink-200"
                    >
                      示例：写文件到本地
                    </button>
                  </div>
                </div>
              </div>
            )}

            {messages.map((m) => (
              <MessageBubble
                key={m.id}
                role={m.role}
                text={m.text}
                toolInvocations={m.toolInvocations}
                streaming={m.streaming}
                isError={m.isError}
              />
            ))}
          </div>
        </div>

        {/* 附件预览 */}
        {attachments.length > 0 && (
          <div className="px-4 pb-1 flex flex-wrap gap-2">
            {attachments.map((a, i) => (
              <div
                key={i}
                className="flex items-center gap-2 rounded-full bg-ink-800/70 border border-ink-700/60 text-xs px-3 py-1.5 text-ink-200"
              >
                <span className="truncate max-w-[280px]">📎 {a.path}</span>
                <button
                  onClick={() =>
                    setAttachments((prev) => prev.filter((_, j) => j !== i))
                  }
                  className="text-ink-400 hover:text-white"
                >
                  ✕
                </button>
              </div>
            ))}
          </div>
        )}

        {/* 输入区 */}
        <footer className="shrink-0 border-t border-ink-800/80 px-4 py-3 bg-ink-950/40 backdrop-blur-sm">
          <div className="max-w-3xl mx-auto">
            <div className="glass rounded-2xl p-2 flex items-end gap-2">
              {isDesktopEnv() && (
                <button
                  className="shrink-0 h-9 px-2 rounded-lg text-sm text-ink-200 hover:bg-ink-800/70 border border-ink-700/60"
                  onClick={handleAttachFile}
                  title="把本地文件内容附加到输入"
                >
                  📎
                </button>
              )}
              <textarea
                ref={textareaRef}
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={onKeyDown}
                rows={1}
                placeholder={
                  hasKey
                    ? "输入消息，回车发送，Shift+回车换行。" + (isDesktopEnv() ? "可用 📎 附加本地文件。" : "")
                    : "请先在左下角「设置」中填入你的 Agnes API Key..."
                }
                disabled={!hasKey || isRunning}
                className="flex-1 resize-none bg-transparent px-2 py-2 text-sm text-ink-100 placeholder:text-ink-500 focus:outline-none leading-relaxed max-h-[220px]"
              />
              {isRunning ? (
                <button
                  className="btn !py-2 !px-3 text-sm"
                  onClick={onStop}
                  title="停止生成"
                >
                  停止
                </button>
              ) : (
                <button
                  className="btn-primary !py-2 !px-3 text-sm"
                  onClick={onSend}
                  disabled={(!input.trim() && attachments.length === 0) || !hasKey}
                >
                  发送
                </button>
              )}
            </div>
            <div className="mt-1.5 text-[11px] text-ink-500 text-center">
              模型：agnes-2.0-flash（对话/推理） · agnes-image-2.1-flash（图像） ·
              agnes-video-v2.0（视频）
            </div>
          </div>
        </footer>
      </main>

      {/* 设置面板 */}
      <SettingsPanel
        open={showSettings}
        onClose={() => setShowSettings(false)}
        onSaved={onKeySaved}
      />
    </div>
  );
}
